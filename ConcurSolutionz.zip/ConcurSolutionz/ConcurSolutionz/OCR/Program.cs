//#pragma warning disable 8600, 8602


//public class Program
//{
//    public static void Main(String[] args)
//    {
//        ReceiptOCR r = new ReceiptOCR("../bin/1.jpg", "../bin/tesseract");
//        Console.WriteLine(r.receiptNumber);
//        Console.WriteLine(r.reqAmount);
//    }
//}

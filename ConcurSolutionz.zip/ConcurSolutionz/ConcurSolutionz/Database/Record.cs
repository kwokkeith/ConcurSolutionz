
namespace ConcurSolutionz.Database
{
    public abstract class Record
    {
        public int RecordID {get; set; }

        public string SubType {get; set;}

    }
}